"""Vision modules for camera/frame processing."""
