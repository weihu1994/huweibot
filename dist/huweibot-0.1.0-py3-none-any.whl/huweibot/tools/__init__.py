"""Utility tools for local diagnostics and validation."""

