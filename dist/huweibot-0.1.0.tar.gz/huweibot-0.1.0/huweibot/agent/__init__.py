"""Agent modules for planning, routing, verification, and macros."""
