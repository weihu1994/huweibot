"""Control modules for physical hardware abstraction."""
